import React, { useState } from 'react';
import './App.css';

const WeatherComponent = () => {
  const [query, setQuery] = useState('');
  const [weatherData, setWeatherData] = useState(null);

  const api = {
    key: "3ee32176fbc4070662893138e0e9dea6",
    base: "https://api.openweathermap.org/data/2.5/"
  };

  const fetchWeatherData = async () => {
    try {
      const response = await fetch(`${api.base}weather?q=${query}&lang=pt_br&units=metric&APPID=${api.key}`);
      const data = await response.json();
      setWeatherData(data);
    } catch (error) {
      console.error('Error fetching weather data:', error);
    }
  };

  const handleSearch = () => {
    fetchWeatherData();
  };

  const getBackgroundColor = () => {
    if (weatherData && weatherData.main.temp > 15) {
      return 'quente';
    } else {
      return 'frio';
    }
  };

  return (
    
    <div className={`container ${getBackgroundColor()}`}>
     <div className='pesquisa'> <input
        type="text"
        placeholder="Digite a cidade"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <button onClick={handleSearch}>Pesquisar</button>
      </div>
      <div className='resultado'>
      {weatherData && (
        <div className="retorno">
          <h2>{weatherData.name}</h2>
          <p>Temperatura: {weatherData.main.temp}°C</p>
          <p>Condição: {weatherData.weather[0].description}</p>
          <img
            src={`https://openweathermap.org/img/wn/${weatherData.weather[0].icon}.png`}
            alt={weatherData.weather[0].description}
          />
        </div>
      )}
    </div>
    </div>
  );
};

export default WeatherComponent;